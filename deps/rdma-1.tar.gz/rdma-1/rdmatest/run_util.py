## helper functions for various script

def print_with_tag(tag,s):
    print "[%s] %s" % (tag,s)
