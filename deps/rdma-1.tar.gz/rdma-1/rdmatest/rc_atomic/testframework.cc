#include "rdmaio.h"
#include "all.h"
#include "TestConfig.h"
#include <getopt.h>

#define MAX_SERVERS 64

double tput[MAX_SERVERS];
TestConfig config;

int stick_this_thread_to_core(int core_id) {
	int num_cores = sysconf(_SC_NPROCESSORS_ONLN);
	if (core_id < 0 || core_id >= num_cores)
		return EINVAL;

	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	CPU_SET(core_id, &cpuset);

	pthread_t current_thread = pthread_self();    
	return pthread_setaffinity_np(current_thread, sizeof(cpu_set_t), &cpuset);
}

void *run_server(void *arg) {
	struct thread_config configs = *(struct thread_config *) arg;
	int thread_id = configs.id;	/* Global ID of this server thread */
	// bindToCore(thread_id);
	/*
	 * Pinning is useful when running servers on 2 sockets - we want to check
	 * if socket 0's cores are getting higher tput than socket 1, which is hard
	 * if threads move between cores.
	 */
	if(configs.num_threads > 16) {
		printf("main: Server is running on two sockets. Pinning threads"
			" using CPU_SET\n");
		sleep(2);
		stick_this_thread_to_core(thread_id);
	}

	RdmaCtrl *rdma = bootstrap_rc_rdma(configs.node_id, config.network, config.port,
		thread_id, NULL, config.userBufSize, config.rcPerThread);
	memset((void *) rdma->conn_buf_, (uint8_t) thread_id + 1, config.userBufSize);

	long long rolling_iter = 0;	/* For performance measurement */
	int qp_i = 0;	
	
	struct timespec start, end;
	clock_gettime(CLOCK_REALTIME, &start);

	int offset = CACHELINE_SIZE;
	while(offset < config.reqLength) {
		offset += CACHELINE_SIZE;
	}
	assert(offset * config.batchSize <= config.userBufSize);
	RdmaReq reqs[MAX_DOORBELL_SIZE];
	// for(int i = 0; i < config.batchSize; i++){
	// 	reqs[i].opcode = configs.opcode;
	// 	reqs[i].flags = 0;
	// 	reqs[i].buf = (uint64_t) (uintptr_t) &rdma->conn_buf_[offset * i];
	// 	reqs[i].length = config.reqLength;
	// 	reqs[i].wr.rdma.remote_offset = offset * i;
	// }
	for(int i = 0; i < config.batchSize; i++){
		reqs[i].opcode = configs.opcode;
		reqs[i].flags = IBV_SEND_SIGNALED;
		reqs[i].buf = (uint64_t) (uintptr_t) &rdma->conn_buf_[offset * i];
		reqs[i].wr.atomic.remote_offset = offset * i;
		reqs[i].wr.atomic.compare_add = 0;
		reqs[i].wr.atomic.swap = 1;
	}
	int num_nodes = rdma->get_num_nodes();
	while(1) {
		if(rolling_iter >= config.iterationNum) {
			clock_gettime(CLOCK_REALTIME, &end);
			double seconds = (end.tv_sec - start.tv_sec) + 
				(double) (end.tv_nsec - start.tv_nsec) / 1000000000;

			tput[thread_id] = config.iterationNum / seconds;
			printf("main: Server %d: %.2f Mops,latency %.4f\n", thread_id, tput[thread_id],1000000/tput[thread_id]);

			/* Collecting stats at every server can reduce tput by ~ 10% */
			if(thread_id == 0 && rand() % 5 == 0) {
				double total_tput = 0;
				for(int i = 0; i < MAX_SERVERS; i++) {
					total_tput += tput[i];
				}
				printf("---------------main: Total throughput = %.2f\n", total_tput);
			}
			rolling_iter = 0;
			clock_gettime(CLOCK_REALTIME, &start);
		}
		for(int nid = 0; nid < num_nodes; nid++){
			if(nid == configs.node_id)continue;
			int qid = _QP_ENCODE_ID(nid,qp_i+config.rcPerThread*thread_id+RC_ID_BASE);
			// rdma->post_rc_doorbell(qid, config.batchSize, reqs);
			// rolling_iter += config.batchSize;
			rdma->post_rc_atomic(qid,reqs);
			rdma->poll_cq(qid);
			rolling_iter++;
		}
		/* Use a different QP for the next postlist */
		qp_i++;
		if(qp_i == config.rcPerThread) {
			qp_i = 0;
		}
	}

	return NULL;
}

void *run_client(void *arg) {
	struct thread_config configs = *(struct thread_config *) arg;
	int thread_id = configs.id;	/* Global ID of this server thread */

	RdmaCtrl *rdma = bootstrap_rc_rdma(configs.node_id, config.network, config.port,
		thread_id, NULL, config.userBufSize, config.rcPerThread);	

	while(1) {
		printf("main: Client %d: %d\n", thread_id, rdma->conn_buf_[0]);
		sleep(1);
	}
}

int main(int argc, char *argv[]) {
	int num_threads, is_client, node_id;
	ibv_wr_opcode opcode;	
	static struct option opts[] = {
		{ "num-threads",    1, NULL, 't' },
		{ "node-id",     1, NULL, 'n' },
		{ 0 }
	};

	/* Parse and check arguments */
	while(1) {
		int c = getopt_long(argc, argv, "t:n:", opts, NULL);
		if(c == -1) {
			break;
		}
		switch (c) {
			case 't':
				num_threads = atoi(optarg);
				break;
			case 'n':
				node_id = atoi(optarg);
				break;
			default:
				printf("Invalid argument %d\n", c);
				assert(false);
		}
	}

	config.readFile("testframework.cfg");
	config.readNetwork();
	config.readPort();
	config.readOp();
	config.readReqLength();
	config.readBatchSize();
	config.readPerMac(node_id);
	config.readUserBufSize();
	config.readRcPerThread();
	config.readIterationNum();

	is_client = node_id == 0 ? 0 : 1;
	opcode = config.op == 1 ? IBV_WR_ATOMIC_CMP_AND_SWP : IBV_WR_ATOMIC_FETCH_AND_ADD;

	assert(num_threads >= 1);
	assert(config.batchSize <= MAX_DOORBELL_SIZE);
	assert(1 <= config.batchSize);
	assert(node_id >= 0);
	assert(config.reqLength >= 0);
	
	for(int i = 0; i < MAX_SERVERS; i++) {
		tput[i] = 0;
	}

	printf("main: Using %d threads\n", num_threads);
	struct thread_config *configs = (struct thread_config*)malloc(num_threads * sizeof(struct thread_config));
	pthread_t *threads = (pthread_t*)malloc(num_threads * sizeof(pthread_t));

	for(int i = 0; i < num_threads; i++) {
		if(is_client) {
			configs[i].node_id = node_id;
			configs[i].id = i;
			pthread_create(&threads[i], NULL, run_client, &configs[i]);
		} else {
			configs[i].node_id = node_id;
			configs[i].num_threads = num_threads;
			configs[i].id = i;
			configs[i].opcode = opcode;
			pthread_create(&threads[i], NULL, run_server, &configs[i]);
		}
	}
	for(int i = 0; i < num_threads; i++) {
		pthread_join(threads[i], NULL);
	}

	return 0;
}
