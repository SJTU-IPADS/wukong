#include "ralloc.h"
#include "rdmaio.h"

#include "all.h"

#include <getopt.h>

#define MAX_SERVERS 64

double tput[MAX_SERVERS];

TestConfig config;

// the functions that will be overwritten by the specified test implementation
void *run_server(void *arg); // server function
void *run_client(void *arg); // client function

extern uint64_t one_second;

using namespace rdmaio;

int stick_this_thread_to_core(int core_id) {

  int num_cores = sysconf(_SC_NPROCESSORS_ONLN);
  if (core_id < 0 || core_id >= num_cores)
    return EINVAL;

  cpu_set_t cpuset;
  CPU_ZERO(&cpuset);
  CPU_SET(core_id, &cpuset);

  pthread_t current_thread = pthread_self();
  return pthread_setaffinity_np(current_thread, sizeof(cpu_set_t), &cpuset);
}

int main(int argc, char *argv[]) {

  int num_threads, is_client, node_id;
  ibv_wr_opcode opcode;
  static struct option opts[] = {
    { "num-threads",    1, NULL, 't' },
    { "node-id",     1, NULL, 'n' },
    { 0 }
  };

  /* Parswe and check arguments */
  while(1) {
    int c = getopt_long(argc, argv, "t:n:", opts, NULL);
    if(c == -1) {
      break;
    }
    switch (c) {
    case 't':
      num_threads = atoi(optarg);
      break;
    case 'n':
      node_id = atoi(optarg);
      break;
    default:
      printf("Invalid argument %d\n", c);
      assert(false);
    }
  }

  config.open_file("config.xml");

  config.read_network();
  config.read_port();
  config.read_op();
  config.read_req_length();
  config.read_batch_size();
  config.read_user_bufsize();
  config.read_rc_per_thread();
  config.read_uc_per_thread();
  config.read_ud_per_thread();
  is_client = node_id == 0 ? 1 : 0;
  switch(config.op_){
    case 0:
      opcode = IBV_WR_RDMA_WRITE;
      break;
    case 1:
      opcode = IBV_WR_RDMA_READ;
      break;  
  }

  assert(num_threads >= 1);
  assert(config.batch_size_ <= MAX_DOORBELL_SIZE);
  assert(1 <= config.batch_size_);
  assert(node_id >= 0);
  assert(config.req_length_ >= 0);

  for(int i = 0; i < MAX_SERVERS; i++) {
    tput[i] = 0;
  }

  printf("main: Using %d threads, user buf size %lu\n", num_threads,config.user_bufsize_);
  struct thread_config *configs = (struct thread_config*)malloc(num_threads * sizeof(struct thread_config));
  pthread_t *threads = (pthread_t*)malloc(num_threads * sizeof(pthread_t));

  // init RDMA config
  RdmaCtrl *cm = new RdmaCtrl(node_id,config.network_,config.port_,true);
  char *buffer = (char *)malloc(config.user_bufsize_);
  
  // cm->open_device();//single
  if(config.rc_per_thread_ > 0 || config.uc_per_thread_ > 0){
    printf("using connect mr\n");
    cm->set_connect_mr(buffer,config.user_bufsize_); // NULL, just using the default allocation strategy
    // cm->register_connect_mr();//single
  }
  if(config.ud_per_thread_ > 0){
    printf("using dgram mr\n");
    cm->set_dgram_mr(buffer,config.user_bufsize_); // NULL, just using the default allocation strategy
    // cm->register_dgram_mr();
  }
  cm->start_server();

  // if(config.rc_per_thread_ > 0){
  //   for(uint j = 0; j < num_threads; ++j){
  //     for(uint i = 0;i < cm->get_num_nodes();++i) {
  //       cm->create_rc_qp(j,i,0,1);
  //     }
  //   } //single
  // }
  // if(config.uc_per_thread_ > 0) {
  //   for(uint j = 0; j < num_threads; ++j){
  //     for(uint i = 0;i < cm->get_num_nodes();++i) {
  //       cm->create_uc_qp(j,i,0,1);
  //     }
  //   } //single
  // }
  // if(config.ud_per_thread_ > 0) {
  //   for(uint j = 0; j < num_threads; ++j){
  //     for(uint i = 0;i < cm->get_num_nodes();++i) {
  //       cm->create_ud_qp(j,i,0,1);
  //     }
  //   } //single
  // }
  

  // init ralloc
  //RInit((char *)(cm->conn_buf_),config.user_bufsize_);

  // check the time
  {
    char buffer[80];

    time_t rawtime;
    time (&rawtime);

    tm *timeinfo = localtime(&rawtime);

    strftime(buffer,sizeof(buffer),"Prepared to started, at %d-%m-%Y %I:%M:%S",timeinfo);
    std::string str(buffer);
    std::cout<<str<<endl;
  }


  for(int i = 0; i < num_threads; i++) {
    if(is_client) {
      configs[i].node_id = node_id;
      configs[i].id = i;
      configs[i].num_threads = num_threads;
      configs[i].opcode = opcode;
      configs[i].cm = cm;
      pthread_create(&threads[i], NULL, run_client, &configs[i]);
    } else {
      configs[i].node_id = node_id;
      configs[i].num_threads = num_threads;
      configs[i].id = i;
      configs[i].opcode = opcode;
      configs[i].cm = cm;
      pthread_create(&threads[i], NULL, run_server, &configs[i]);
    }
  }
  fprintf(stdout,"Wait for joining... \n");

  for(int i = 0; i < num_threads; i++) {
    pthread_join(threads[i], NULL);
  }
  fprintf(stdout,"Benchmark done\n");
  return 0;
}
