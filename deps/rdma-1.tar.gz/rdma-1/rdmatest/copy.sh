cp $1.cc $2
cp $1.cfg $2
