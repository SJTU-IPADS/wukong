#include <vector>
#include <string>
#include <sstream>
#include <assert.h>

#include <boost/foreach.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/ini_parser.hpp>
#include <boost/property_tree/xml_parser.hpp>

#include <boost/algorithm/string.hpp>

using namespace boost;
using boost::property_tree::ptree;
using namespace property_tree;

using namespace std;

class TestConfig{
 public:
	TestConfig(){ }
	~TestConfig(){ }

	void open_file(string configPath) {
		read_xml(configPath, pt_);
	}

	inline void read_op() {
		// xml version
		op_ = pt.get<int>("param.op");
	}

	inline void read_req_length() {
		req_length_ = pt.get<int>("param.reqLength");
	}

	inline void read_work_count() {
		work_count_ = pt.get<int>("param.workCount");
	}

	inline void read_port() {
		port_ = pt.get<int>("param.port");
	}
<<<<<<< HEAD

	inline void read_batch_size() {
		batch_size_ = pt.get<int>("param.batchSize");
=======
	inline void readRecvUcPerThread(){
		readConfigInt("recvUcPerThread", recvUcPerThread);	
	}
	inline void readRecvUdPerThread(){
		readConfigInt("recvUdPerThread", recvUdPerThread);	
>>>>>>> 555aae59a9cb72c63f2547f6b6a5c556eba6679f
	}

	inline void read_iter_num() {
		iters_ = pt.get<int>("iter");
	}

	inline void read_network() {
		BOOST_FOREACH(ptree::value_type &v,
					  pt_.get_child("param.network.a")) {
			string s = v.second.data();
			boost::algorithm::trim_right(s);
			boost::algorithm::trim_left(s);
			network_.push_back(s);
		}
	}

	inline void read_user_bufsize() {
		string s_bufsize = pt_.get<string>("param.userBuf");
		user_bufsize_ = convert_buf_size(s_bufsize);
	}

	inline void read_rc_per_thread() {
		rc_per_thread_ = pt_.get<int>("param.rcPerThread");
	}
<<<<<<< HEAD

	//	inline void readWorkCount(){
	//readConfigInt("workCount", workCount);
	//}
	//inline void readPort(){
	//readConfigInt("port", port);
	//}
	//inline void readBatchSize(){
	//readConfigInt("batchSize", batchSize);
	//}
	//	inline void readIterationNum(){
	//readConfigInt("iterationNum", iterationNum);
	//}
	//	inline void readRcPerThread(){
	//readConfigInt("rcPerThread", rcPerThread);
	//}
	//	inline void readUcPerThread(){
	//readConfigInt("ucPerThread", ucPerThread);
	//}
	//	inline void readUdPerThread(){
	//readConfigInt("udPerThread", udPerThread);
	//}
	//inline void readRecvRcPerThread(){
	//readConfigInt("recvRcPerThread", recvRcPerThread);
	//}
	//inline void readRecvUdPerThread(){
	//readConfigInt("recvUdPerThread", recvUdPerThread);
	//}
	//inline void readNetwork(){
	//	readConfigStringVector("network", network);
	//}
	//	inline void readUserBufSize(){
	//readConfigBufSize("userBufSize", userBufSize);
	//}
	//inline void readRecvBufSize(){
	//readConfigBufSize("recvBufSize", recvBufSize);
	//}

	/************************************************************************************/
	/* void readPerMac(int id){														    */
	/* 	char path[] = "perMac";														    */
	/* 	setting = config_lookup(&cfg, path);										    */
	/* 	if(!setting){																    */
	/* 		fprintf(stderr, "Read Config Error-> path: %s\n", path);				    */
	/* 		return;																	    */
	/* 	}																			    */
	/* 	int count = config_setting_length(setting);									    */
	/* 	assert(id < count);															    */
	/* 																				    */
	/* 	config_setting_t* perMac = config_setting_get_elem(setting, id);			    */
	/* 	if(!perMac){																    */
	/* 		fprintf(stderr, "Read Setting Error-> path: %s, id: %d\n", path, id);	    */
	/* 		return;																	    */
	/* 	}																			    */
	/* 																				    */
	/* 	readSettingInt(perMac, "sendThreads", sendThreads);							    */
	/* 	readSettingInt(perMac, "recvThreads", recvThreads);							    */
	/* 																				    */
	/* 	if(sendThreads > 0){														    */
	/* 		char path[] = "targets";												    */
	/* 		config_setting_t* tgts = config_setting_lookup(perMac, path);			    */
	/* 		if(!tgts){																    */
	/* 			fprintf(stderr, "Read Setting Error-> path: %s\n", path);			    */
	/* 			return;																    */
	/* 		}																		    */
	/* 		if(!(count = config_setting_length(tgts))) return;						    */
	/* 		printf("Read Setting-> %-15s: ", path);									    */
	/* 		for(int i = 0; i < count; i++){											    */
	/* 			int target = config_setting_get_int_elem(tgts, i);					    */
	/* 			targets.push_back(target);											    */
	/* 			printf("%d ", target);												    */
	/* 		}																		    */
	/* 		putchar('\n');															    */
	/* 	}																			    */
	/* }																			    */
	/************************************************************************************/
	int op_;
	int req_length_;
	int work_count_;
	int port_;
	int batch_size_;
	int iters_;
	int rc_per_thread_;
	uint64_t user_bufsize_;
	vector<string> network_;
	//int sendThreads;
	//int recvThreads;
	//int batchSize;

	//int iterationNum;
	//int rcPerThread;
	//int ucPerThread;
	//int udPerThread;
	//int recvRcPerThread;
	//int recvUdPerThread;
	//uint64_t userBufSize;
	//uint64_t recvBufSize;
	//vector<int> targets;
 private:
	ptree pt_;
	/*
=======
	int op;
	int reqLength;
	int workCount;
	int port;
	int sendThreads;
	int recvThreads;
	int batchSize;
	int iterationNum;
	int rcPerThread;
	int ucPerThread;
	int udPerThread;
	int recvRcPerThread;
	int recvUcPerThread;
	int recvUdPerThread;
	uint64_t userBufSize;
	uint64_t recvBufSize;
	vector<int> targets;
	vector<string> network;
private:
>>>>>>> 555aae59a9cb72c63f2547f6b6a5c556eba6679f
	config_t cfg;
	config_setting_t *setting;

	void readConfigString(string path, string& param){
		const char* str;
		if(config_lookup_string(&cfg, path.c_str(), &str)){
			printf("Read Config-> %-15s: %s\n", path.c_str(), str);
			param = string(str);
		} else {
			fprintf(stderr, "Read Config Error-> path: %s.\n", path.c_str());
			exit(-1);
		}
	}

	void readConfigInt(string path, int& param){
		if(config_lookup_int(&cfg, path.c_str(), &param)){
			printf("Read Config-> %-15s: %d\n", path.c_str(), param);
		} else {
			fprintf(stderr, "Read Config Error-> path: %s.\n", path.c_str());
			exit(-1);
		}
	}

	void readSettingInt(config_setting_t* set, string path, int& param){
		if(config_setting_lookup_int(set, path.c_str(), &param)){
			printf("Read Setting-> %-15s: %d\n", path.c_str(), param);
		} else {
			fprintf(stderr, "Read Setting Error-> path: %s.\n", path.c_str());
			exit(-1);
		}
	}

	void readConfigStringVector(string path, vector<string>& param){
		setting = config_lookup(&cfg, path.c_str());
		if(setting != NULL){
			int count = config_setting_length(setting);
			for(int i = 0; i < count; i++){
				const char* cstr;
				if(!(cstr = config_setting_get_string_elem(setting, i))){
					fprintf(stderr, "Read Config Error-> path: %-15s, index: %d", path.c_str(), i);
					exit(-1);
				}
				printf("Read Config-> %-15s: %s [%d]\n", path.c_str(), cstr, i);
				param.push_back(string(cstr));
			}
		}
	}

	void readConfigBufSize(string path, uint64_t& param){
		string bufString;
		char unit;
		readConfigString(path, bufString);
		stringstream ss(bufString);
		assert(ss >> param);

		if(!(ss >> unit))return;
		switch(unit){
		case 'g': case 'G':
			param *= 1024;
		case 'm': case 'M':
			param *= 1024;
		case 'k': case 'K':
			param *= 1024;
		}
		printf("Read Config-> %-15s: %ld bytes\n", path.c_str(), param);
	}
	*/
	uint64_t convert_buf_size(string buf_size) {

		uint64_t size;
		stringstream ss(buf_size);
		assert(ss >> size);
		char unit;
		if(!(ss >> unit)) return size;

		switch(unit){
		case 'g': case 'G':
			size *= 1024;
		case 'm': case 'M':
			size *= 1024;
		case 'k': case 'K':
			size *= 1024;
		}
		return size;
	}
};

