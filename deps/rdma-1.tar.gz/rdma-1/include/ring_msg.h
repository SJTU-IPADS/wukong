#ifndef RDMA_RING_MSG_
#define RDMA_RING_MSG_

#include "rdmaio.h"
#include "rdma_msg.h"

/*
 * Layout of message buffer in RDMA registered region
 * | meta data | ring buffer | overflow padding |
 */


namespace rdmaio {

  namespace ringmsg {

    // constants
    const uint8_t MAX_BROADCAST_SERVERS = 32;
    const uint8_t MSG_META_SZ = sizeof(uint64_t);
    const uint8_t  MSG_MAX_MAC_SUPPORTED = 64;

    const uint32_t MSG_DEFAULT_PADDING = (16 * 1024);
    const uint32_t MSG_DEFAULT_SZ = (4 * 1024 * 1024 - MSG_META_SZ - MSG_DEFAULT_PADDING);

    class RingMessage : public RDMA_msg {

    public:
      /*
       * ringSz:      The buffer for receiving messages.
       * ringPadding: The overflow buffer for one message. msgsize must <= ringPadding
       * basePtr:     The start pointer of the total message buffer used at one server
       */
      RingMessage(uint64_t ring_size,uint64_t ring_padding,int thread_id,RdmaCtrl *cm,char *base_ptr);
      RingMessage(int thread_id,RdmaCtrl *cm,char *base_ptr);

      Qp::IOStatus send_to(int node_id,char *msg,int len);
      Qp::IOStatus broadcast_to(int *node_ids, int num_of_node, char *msg,int len);

      // force a sync among all current in-flight messages, return when all these msgs are ready
      void force_sync(int *node_id,int num_of_node);

      // Return true if one message is received
      bool  try_recv_from(int from_mac,char *buffer);

      // if we receive one
      void  ack_msg();

      int   get_num_nodes() { return num_nodes_; }
      int   get_thread_id() { return thread_id_; }

      virtual void check();

    private:
      std::vector<Qp *> qp_vec_;
      // The ring buffer size
      const uint64_t ring_size_;
      const uint64_t ring_padding_;
      const uint64_t total_buf_size_;

      // The base offset used to send message
      uint64_t base_offset_;

      // Receive side buffering
      uint64_t *poll_ptr_;
      uint64_t  msg_size_;
      //int from_mac_;

      // num nodes in total
      int num_nodes_;
    public:
      // my node id
      int node_id_;

      /* Local base offset */
      char *base_ptr_;
      RdmaCtrl *cm_;

      /* Local offsets used for polling */
      uint64_t offsets_[MSG_MAX_MAC_SUPPORTED];

      /* Remote offsets used for sending messages */
      uint64_t headers_[MSG_MAX_MAC_SUPPORTED];

      /* The thread id */
      int thread_id_;
    };

  }
};

#endif
