#include "ud_msg.h"

#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>


namespace rdmaio {

  namespace udmsg {

    UDMsg::UDMsg() {
      // TODO
    }

    Qp::IOStatus UDMsg::send_to(int node_id,char *msg,int len) {
      return Qp::IO_ERR;
    }

    Qp::IOStatus UDMsg::broadcast_to(int *node_ids, int num_of_node, char *msg,int len) {
      return Qp::IO_ERR;
    }

    void UDMsg::force_sync(int *node_id,int num_of_node) {
      return;
    }


    void UDMsg::check() {
      // TODO
    }

    // dummy methods for backward compatibility

    bool  UDMsg::try_recv_from(int from_mac,char *buffer) {
      assert(false); // cannot be implemented in UD msg
      return false;
    }

    void  ack_msg() {

    }
  }; // end namespace ud msg

}; // end namespace rdmaio
