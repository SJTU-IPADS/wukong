// implementation of the RdmaCtrl class

#include <malloc.h>

#include <arpa/inet.h> //used for checksum

#include "rdmaio.h"
#include "../utils/utils.h"
#include "helper_func.hpp"

namespace rdmaio {

    int tcp_base_port;
    int node_id;
    std::vector<std::string> network;

    // per-thread allocator
    __thread RdmaDevice **rdma_devices_;

    RdmaCtrl::RdmaCtrl(int id, const std::vector<std::string> net,
                       int port, bool enable_per_thread_mr):
        node_id_(id),network_(net.begin(),net.end()),tcp_base_port_(port),
        recv_helpers_(NULL),remote_ud_qp_attrs_(NULL),//qps_(NULL),
        num_rc_qps_(1),num_uc_qps_(1),enable_per_thread_mr_(enable_per_thread_mr)
        //    RdmaCtrl::RdmaCtrl(int node_id, const std::vector<std::string> network,
        //int tcp_base_port, bool enable_per_thread_mr):
        //node_id_(node_id),network_(network.begin(),
        //network.end()),tcp_base_port_(tcp_base_port),
        //qps_(NULL),remote_ud_qp_attrs_(NULL),recv_helpers_(NULL),
        //num_rc_qps_(1),num_uc_qps_(1),num_ud_qps_(1),enable_per_thread_mr_(enable_per_thread_mr)
    {

        assert(node_id >= 0);

        // init global locks
        mtx_ = new std::mutex();
        ud_mtx_ = new std::mutex();

        qps_.clear();

        // record
        tcp_base_port = tcp_base_port_;
        node_id = node_id_;
        network = std::vector<std::string>(net.begin(),net.end());

        query_devinfo();
        if(enable_per_thread_mr_)rdma_single_device_ = new RdmaDevice;
        /////////////////////////////////////////////////////////////////////////////////////////////////
        // 	int port_index;                                                                            //
        // #if DUAL_PORT                                                                               //
        // 	port_index = thread_id % 2;                                                                //
        // #else                                                                                       //
        // 	port_index = 0;                                                                            //
        // #endif                                                                                      //
        // 	dev_id_ = get_active_dev(port_index);                                                      //
        //     fprintf(stdout,"[RDMACTL INIT], using %d device for thread %d\n",dev_id_,thread_id);    //
        // 	dev_port_id_ = get_active_port(port_index);                                                //
        // 	struct ibv_device *ib_dev = dev_list_[dev_id_];                                            //
        // 	CE_1(!ib_dev, "[librdma] %2d: Device not found", thread_id_);                              //
        //                                                                                             //
        // 	open_device();                                                                             //
        /////////////////////////////////////////////////////////////////////////////////////////////////
    }

    void RdmaCtrl::thread_local_init() {
        //single memory region
        if(enable_per_thread_mr_) return;
        // the device related object shall be created locally
        rdma_devices_ = new RdmaDevice*[num_devices_];
        for(uint i = 0;i < num_devices_;++i)
            rdma_devices_[i] = NULL;
    }

    void RdmaCtrl::query_devinfo() {
        int rc;

        dev_list_ = ibv_get_device_list (&num_devices_);
        CE(!num_devices_,"[librdma] : failed to get IB devices list\n");
        printf("[librdma] : Total %d devices!\n", num_devices_);

        active_ports_ = new int[num_devices_];
        num_ports_ = 0;
        for(int device_id = 0; device_id < num_devices_; device_id++){

            printf("[librdma] get device name %s, idx %d\n",dev_list_[device_id]->name,device_id);
            struct ibv_context *ib_ctx = ibv_open_device(dev_list_[device_id]);
            CE_1(!ib_ctx, "[librdma] : Failed to open device %d\n", device_id);

            struct ibv_device_attr device_attr;
            memset(&device_attr, 0, sizeof(device_attr));

            rc = ibv_query_device(ib_ctx, &device_attr);
            CE_1(rc, "[librdma] : Failed to query device %d\n", device_id);

            int port_num = 0, port_count = device_attr.phys_port_cnt;
            for(int port_id = 1; port_id <= port_count; port_id++){
                struct ibv_port_attr port_attr;
                rc = ibv_query_port(ib_ctx, port_id, &port_attr);
                CE_2(rc, "[librdma] : Failed to query port %d on device %d\n ", port_id, device_id);

                if(port_attr.phys_state != IBV_PORT_ACTIVE &&
                   port_attr.phys_state != IBV_PORT_ACTIVE_DEFER) {
                    // printf("\n[librdma] Ignoring port %d on device %d. State is %s\n",
                    //   port_id, device_id, ibv_port_state_str((ibv_port_state) port_attr.phys_state));
                    continue;
                }
                port_num++;
            }
            printf("[librdma] : Device %d has %d ports\n", device_id, port_num);
            active_ports_[device_id] = port_num;
            num_ports_ += port_num;

            rc = ibv_close_device(ib_ctx);
            CE_1(rc, "[librdma] : Failed to close device %d", device_id);
        }
        printf("[librdma] : Total %d Ports!\n", num_ports_);
    }

    int RdmaCtrl::get_active_dev(int port_index){
        assert(port_index >= 0 && port_index < num_ports_);
        for(int device_id = 0; device_id < num_devices_; device_id++){
            int port_num = active_ports_[device_id];
            for(int port_id = 1; port_id <= port_num; port_id++){
                if(port_index == 0)return device_id;
                port_index--;
            }
        }
        return -1;
    }

    int RdmaCtrl::get_active_port(int port_index){

        assert(port_index >= 0 && port_index < num_ports_);
        for(int device_id = 0; device_id < num_devices_; device_id++){
            int port_num = active_ports_[device_id];
            for(int port_id = 1; port_id <= port_num; port_id++){
                if(port_index == 0)return port_id;
                port_index--;
            }
        }
        return -1;
    }

    void RdmaCtrl::open_device(int dev_id) {

        int rc;

        struct ibv_device *device = dev_list_[dev_id];
        //CE_2(!device,"[librdma]: IB device %d wasn't found\n",dev_id);
        RdmaDevice *rdma_device;
        if(enable_per_thread_mr_){
            rdma_device = rdma_single_device_;
        } else if(rdma_devices_[dev_id] == NULL) {
            rdma_device = rdma_devices_[dev_id] = new RdmaDevice();
        } else {
            return;
        }
         
        rdma_device->dev_id = dev_id;
        rdma_device->ctx = ibv_open_device(device);
        //CE_2(!rdma_device->ctx,"[librdma] : failed to open device %d\n",dev_id);

        struct ibv_device_attr device_attr;
        rc = ibv_query_device(rdma_device->ctx,&device_attr);
        //CE_2(rc,"[librdma]: failed to query device %d\n",dev_id);

        int port_count = device_attr.phys_port_cnt;
        rdma_device->port_attrs =(struct ibv_port_attr*)
            malloc(sizeof(struct ibv_port_attr) * (port_count + 1));
        for(int port_id = 1; port_id <= port_count; port_id++){
            rc = ibv_query_port (rdma_device->ctx, port_id, rdma_device->port_attrs + port_id);
            //      CE_2(rc,"[librdma]: ibv_query_port on port %u failed\n",port_id);
        }

        rdma_device->pd = ibv_alloc_pd(rdma_device->ctx);
        //CE_2(!rdma_device_->pd, "[librdma]: ibv_alloc prodection doman failed at dev %d\n",dev_id);
    }

    void RdmaCtrl::set_connect_mr(volatile void *conn_buf, uint64_t conn_buf_size){
        if(conn_buf == NULL) {
            conn_buf = (volatile uint8_t *) memalign(4096, conn_buf_size);
        }
        assert(conn_buf != NULL);
        memset((char *) conn_buf, 0, conn_buf_size);

        conn_buf_ = (volatile uint8_t *)conn_buf;
        conn_buf_size_ = conn_buf_size;
    }

    void RdmaCtrl::set_dgram_mr(volatile void *dgram_buf, int dgram_buf_size){
        if(dgram_buf == NULL) {
            dgram_buf = (volatile uint8_t *) memalign(4096, dgram_buf_size);
        }
        assert(dgram_buf != NULL);
        memset((char *) dgram_buf, 0, dgram_buf_size);
        
        dgram_buf_ = (volatile uint8_t *)dgram_buf;
        dgram_buf_size_ = dgram_buf_size;
    }


    void RdmaCtrl::register_connect_mr(int dev_id) {
        RdmaDevice *rdma_device = get_rdma_device(dev_id);
        assert(rdma_device->pd != NULL);
        rdma_device->conn_buf_mr = ibv_reg_mr(rdma_device->pd,(char *)conn_buf_, conn_buf_size_,
                                              DEFAULT_PROTECTION_FLAG);
        CE_2(!rdma_device->conn_buf_mr, 
            "[librdma]: Connect Memory Region failed at dev %d, err %s\n",dev_id,strerror(errno));
    }

    void RdmaCtrl::register_dgram_mr(int dev_id) {
        RdmaDevice *rdma_device = get_rdma_device(dev_id);
        assert(rdma_device->pd != NULL);
        rdma_device->dgram_buf_mr = ibv_reg_mr(rdma_device->pd,(char *)dgram_buf_, dgram_buf_size_,
                                              DEFAULT_PROTECTION_FLAG);
        CE_2(!rdma_device->dgram_buf_mr
            ,"[librdma]: Datagram Memory Region failed at dev %d, err %s\n",dev_id,strerror(errno));
    }

    Qp *RdmaCtrl::create_rc_qp(int tid, int remote_id,int dev_id,int port_idx) {

        // TODO: check device
        // compute local qp id
        assert(num_rc_qps_ != 0);
        uint64_t qid = _QP_ENCODE_ID(remote_id, RC_ID_BASE + tid * num_rc_qps_);
        Qp *res = NULL;

        mtx_->lock();
        //        fprintf(stdout,"create qp %d %d, qid %lu\n",tid,remote_id,qid);
        //if((res = qps_[qid]) != NULL) {
        if(qps_.find(qid) != qps_.end() && qps_[qid] != nullptr) {
            res = qps_[qid];
            mtx_->unlock();
            return res;
        }
        res = new Qp();
        // set ids
        res->tid = tid;
        res->nid = remote_id;
        res->port_idx = port_idx;

        res->init_rc(get_rdma_device(dev_id),port_idx);
        //qps_.insert(qid,res);
        qps_.insert(std::make_pair(qid,res));
        //fprintf(stdout,"create qp %d %d done %p\n",tid,remote_id,res);
        mtx_->unlock();
        // QP to be connected at remote server
        //int remote_qid = _QP_ENCODE_ID(node_id_,RC_ID_BASE + tid * num_rc_qps_);
        //        RdmaQpAttr *remote_qp_attr = new RdmaQpAttr();

        // get the remote connection data
        //*remote_qp_attr = get_remote_qp_attr(remote_id,remote_qid);

        // change qp states to ready
        //res->connect_conn_qp(remote_qp_attr,port_idx);

        // done
        return res;
    }

    Qp *RdmaCtrl::create_uc_qp(int tid, int remote_id,int dev_id,int port_idx) {
        // TODO: check device

        // compute local qp id
        assert(num_uc_qps_ != 0);
        int32_t qid = _QP_ENCODE_ID(remote_id, UC_ID_BASE + tid * num_uc_qps_);
        Qp *res = NULL;

        mtx_->lock();
        if((res = qps_[qid]) != NULL) {
            mtx_->unlock();
            return res;
        }
        res = new Qp();
        res->init_uc(get_rdma_device(dev_id),port_idx);
        //qps_.insert(qid,res);
        qps_.insert(std::make_pair(qid,res));
        mtx_->unlock();

        // QP to be connected at remote server
        int remote_qid = _QP_ENCODE_ID(node_id_,UC_ID_BASE + tid * num_uc_qps_);
        RdmaQpAttr *remote_qp_attr = new RdmaQpAttr();

        // get the remote connection data
        *remote_qp_attr = get_remote_qp_attr(remote_id,remote_qid);

        // change qp states to ready
        res->connect_conn_qp(remote_qp_attr,port_idx);

        // done
        return res;
    }

    Qp *RdmaCtrl::create_ud_qp(int tid, int remote_id,int dev_id,int port_idx) {
        // TODO: check device
        RdmaDevice *rdma_device = get_rdma_device(dev_id); // XD: single MR case need to check concurrency

        // compute local qp id
        assert(num_ud_qps_ != 0);
        int32_t qid = _QP_ENCODE_ID(remote_id, UD_ID_BASE + tid * num_ud_qps_);
        Qp *res = NULL;

        mtx_->lock();
        if((res = qps_[qid]) != NULL) {
            mtx_->unlock();
            return res;
        }
        res = new Qp();
        res->init_ud(get_rdma_device(dev_id),port_idx);
        //qps_.insert(qid,res);
        qps_.insert(std::make_pair(qid,res));
        mtx_->unlock();

        // QP to be connected at remote server
        uint64_t remote_qid = _QP_ENCODE_ID(remote_id,UD_ID_BASE + tid * num_ud_qps_);
        RdmaQpAttr *remote_qp_attr = new RdmaQpAttr();

        // get the remote connection data
        *remote_qp_attr = get_remote_qp_attr(remote_id,remote_qid);

        // shall do concurrency control
        ud_mtx_->lock();
        remote_ud_qp_attrs_.insert(remote_qid, remote_qp_attr);
        ud_mtx_->unlock();

        int dlid = remote_qp_attr->lid;
        int ah_id = _QP_ENCODE_ID(dlid, port_idx);
        if(rdma_device->ahs[ah_id] == NULL){
            rdma_device->ahs.insert(ah_id, create_ah(dlid,port_idx,rdma_device));
        }

        // done
        return res;
    }


    RdmaQpAttr RdmaCtrl::get_remote_qp_attr(int nid, uint64_t qid) {
        int retry_count = 0;
    retry:
        char address[30];
        snprintf(address,30,"tcp://%s:%d",network_[nid].c_str(),tcp_base_port_+nid);
        zmq::context_t context(1);
        zmq::socket_t socket(context,ZMQ_REQ);
        socket.connect(address);

        zmq::message_t request(sizeof(QPConnArg));
        //    fprintf(stdout,"encode id %d %d\n",this->nodeId,_QP_DECODE_INDEX(qid));
        //*((int *)request.data()) = qid;//////wa! o !
        QPConnArg *argp = (QPConnArg *)(request.data());
        argp->qid = qid;
        argp->sign = MAGIC_NUM;
        argp->calculate_checksum();

        socket.send(request);

        zmq::message_t reply;
        socket.recv(&reply);

        if(((char *)reply.data())[0] == TCPSUCC) {

        } else if(((char *)reply.data())[0] == TCPFAIL) {

            if(retry_count > 10) {
                fprintf(stdout,"response %d, try connect to %d\n",((char *)reply.data())[0],nid);
                assert(false);
            }
            sleep(1);
            retry_count += 1;
            goto retry;

        } else {
            fprintf(stdout,"QP connect fail!, val %d\n",((char *)reply.data())[0]);
            assert(false);
        }

        RdmaQpAttr qp_attr;
        memcpy(&qp_attr,(char *)reply.data() + 1,sizeof(RdmaQpAttr));

        // verify the checksum
        uint64_t checksum = ip_checksum((void *)(&(qp_attr.buf)),sizeof(RdmaQpAttr) - sizeof(uint64_t));
        assert(checksum == qp_attr.checksum);
        return qp_attr;
    }


    RdmaQpAttr RdmaCtrl::get_local_qp_attr(int qid){

        RdmaQpAttr qp_attr;
        Qp *local_qp = qps_[qid];
        assert(local_qp != NULL);
        //uint64_t begin = rdtsc();
        if(IS_CONN(qid)){

            qp_attr.buf = (uint64_t) (uintptr_t) conn_buf_;
            qp_attr.buf_size = conn_buf_size_;
            assert(local_qp->dev_ != NULL);
            assert(local_qp->dev_->conn_buf_mr != NULL);
            qp_attr.rkey = local_qp->dev_->conn_buf_mr->rkey;
            //qp_attr.rkey = rdma_device_->conn_buf_mr->rkey;
            //qp_attr.rkey = qps_[qid]->reg_mr->rkey;
        }
        //qp_attr.lid = qps_[qid]->dev_->port_attrs[dev_port_id_].lid;
        qp_attr.lid = local_qp->dev_->port_attrs[local_qp->port_id_].lid;
        qp_attr.qpn = local_qp->qp->qp_num;
        //fprintf(stdout,"get local qp costs %lu\n",rdtsc() - begin);

        // calculate the checksum
        uint64_t checksum = ip_checksum((void *)(&(qp_attr.buf)),sizeof(RdmaQpAttr) - sizeof(uint64_t));
        qp_attr.checksum = checksum;
        return qp_attr;
    }

    void RdmaCtrl::start_server() {
        pthread_t tid;
        pthread_create(&tid, NULL, recv_thread, (void *)this);
    }

    void* RdmaCtrl::recv_thread(void *arg){

        pthread_detach(pthread_self());
        struct RdmaCtrl *rdma = (struct RdmaCtrl*) arg;

        zmq::context_t context(1);
        zmq::socket_t socket(context,ZMQ_REP);

        char address[30] = "";
        int port = rdma->tcp_base_port_;
            //        char address[30]="";
            //int port = rdma->tcp_base_port_ + rdma->node_id_;
        sprintf(address,"tcp://*:%d",port);
        //	DEBUG(rdma->thread_id_,
		printf("[librdma] : listener binding: %s\n", address);
        socket.bind(address);

        while(1) {

            zmq::message_t request;
            socket.recv(&request);

            //int qid =  *((int *)(request.data()));
            QPConnArg *arg = (QPConnArg *)(request.data());
            // check that the arg is correct
            assert(arg->sign = MAGIC_NUM);
            assert(arg->get_checksum() == arg->checksum);

            int qid = arg->qid;
            int nid = _QP_DECODE_MAC(qid);
            int idx = _QP_DECODE_INDEX(qid);

            zmq::message_t reply(sizeof(RdmaQpAttr) + 1);

            //if(rdma->qps_[qid] == NULL) {
            //  *(char *)(reply.data()) = 0;
            rdma->mtx_->lock();
            if(rdma->qps_.find(qid) == rdma->qps_.end()) {
                //fprintf(stdout,"failed qp fetch for idx %d,@%d, total qps %d\n",idx,nid,rdma->qps_.size());
                *(char *)(reply.data()) = TCPFAIL;
            } else {
                RdmaQpAttr qp_attr = rdma->get_local_qp_attr(qid);
                *(char *)(reply.data()) = TCPSUCC;
                memcpy((char *)(reply.data()) + 1,(char *)(&qp_attr),sizeof(RdmaQpAttr));
            }
            rdma->mtx_->unlock();
            // reply with the QP attribute
            socket.send(reply,ZMQ_NOBLOCK);
            //if(rdma->response_times_ < 0) continue;
            //if(--rdma->response_times_ == 0)break;
        }
        printf("[librdma] : recv thread exit!\n");
    }

    ibv_ah* RdmaCtrl::create_ah(int dlid, int port_index, RdmaDevice* rdma_device){
        struct ibv_ah_attr ah_attr;
        ah_attr.is_global = 0;
        ah_attr.dlid = dlid;
        ah_attr.sl = 0;
        ah_attr.src_path_bits = 0;
        ah_attr.port_num = port_index;

        struct ibv_ah *ah;
        ah = ibv_create_ah(rdma_device->pd, &ah_attr);
        assert(ah != NULL);
        
        return ah;
    }
    void RdmaCtrl::init_conn_recv_qp(int qid){
        RdmaRecvHelper *recv_helper = new RdmaRecvHelper;
        RdmaDevice* rdma_device = qps_[qid]->dev_;
        int recv_step = 0;
        int max_recv_num = RC_MAX_RECV_SIZE;
        while(recv_step < MAX_PACKET_SIZE){
            recv_step += MIN_STEP_SIZE;
        }
        assert(recv_step > 0 && recv_step % MIN_STEP_SIZE == 0);

        printf("recv_step: %d\n", recv_step);
        for(int i = 0; i < max_recv_num; i++) {
            int offset = i * recv_step;

            recv_helper->sge[i].length = recv_step;
            recv_helper->sge[i].lkey = rdma_device->conn_buf_mr->lkey;
            recv_helper->sge[i].addr = (uintptr_t) &conn_buf_[offset];

            recv_helper->rr[i].wr_id = recv_helper->sge[i].addr;/* Debug */
            recv_helper->rr[i].sg_list = &recv_helper->sge[i];
            recv_helper->rr[i].num_sge = 1;

            recv_helper->rr[i].next = (i < max_recv_num - 1) ?
                &recv_helper->rr[i + 1] : &recv_helper->rr[0];
        }
        recv_helper->recv_step = recv_step;
        recv_helper->max_recv_num = max_recv_num;
        recv_helpers_.insert(qid, recv_helper);
        post_conn_recvs(qid, max_recv_num);
    }

    void RdmaCtrl::init_dgram_recv_qp(int qid){
        RdmaRecvHelper *recv_helper = new RdmaRecvHelper;
        RdmaDevice* rdma_device = qps_[qid]->dev_;
        int recv_step = 0;
        int max_recv_num = UD_MAX_RECV_SIZE;
        while(recv_step < MAX_PACKET_SIZE + GRH_SIZE){
            recv_step += MIN_STEP_SIZE;
        }
        assert(recv_step > 0 && recv_step % MIN_STEP_SIZE == 0);

        printf("recv_step: %d\n", recv_step);
        for(int i = 0; i < max_recv_num; i++) {
            int offset = MIN_STEP_SIZE - GRH_SIZE + i * recv_step;

            recv_helper->sge[i].length = recv_step;
            recv_helper->sge[i].lkey = rdma_device->dgram_buf_mr->lkey;
            recv_helper->sge[i].addr = (uintptr_t) &dgram_buf_[offset];

            recv_helper->rr[i].wr_id = recv_helper->sge[i].addr;/* Debug */
            recv_helper->rr[i].sg_list = &recv_helper->sge[i];
            recv_helper->rr[i].num_sge = 1;

            recv_helper->rr[i].next = (i < max_recv_num - 1) ?
                &recv_helper->rr[i + 1] : &recv_helper->rr[0];
        }
        recv_helper->recv_step = recv_step;
        recv_helper->max_recv_num = max_recv_num;
        recv_helpers_.insert(qid, recv_helper);
        post_ud_recvs(qid, max_recv_num);
    }

    int RdmaCtrl::poll_recv_cq(int qid){
        Qp *qp = qps_[qid];
        struct ibv_wc wc;
        int rc = 0;
        int poll_result;

        do {
            poll_result = ibv_poll_cq (qp->recv_cq, 1, &wc);
        } while(poll_result == 0);
        assert(poll_result == 1);

        if (wc.status != IBV_WC_SUCCESS) {
            fprintf (stderr,
                     "got bad completion with status: 0x%x, vendor syndrome: 0x%x, with error %s\n",
                     wc.status, wc.vendor_err,ibv_wc_status_str(wc.status));
        }
        // fprintf(stdout,"poll Recv imm %d, buffer data: %d\n",wc.imm_data,
        //       (*(uint32_t*)(wc.wr_id+GRH_SIZE)));
        return rc;
    }


    int RdmaCtrl::poll_recv_cq(Qp* qp){
        struct ibv_wc wc;
        int rc = 0;
        int poll_result;

        do {
            poll_result = ibv_poll_cq (qp->recv_cq, 1, &wc);
        } while(poll_result == 0);
        assert(poll_result == 1);

        if (wc.status != IBV_WC_SUCCESS) {
            fprintf (stderr,
                     "got bad completion with status: 0x%x, vendor syndrome: 0x%x, with error %s\n",
                     wc.status, wc.vendor_err,ibv_wc_status_str(wc.status));
        }
        // fprintf(stdout,"poll Recv imm %d, buffer data: %d\n",wc.imm_data,
        //       (*(uint32_t*)(wc.wr_id+GRH_SIZE)));
        return rc;
    }

    int RdmaCtrl::poll_cqs(int qid, int cq_num){
        struct ibv_wc wc[RC_MAX_SEND_SIZE];
        int rc = 0;
        int poll_result = 0;
        Qp *qp = qps_[qid];
        while(poll_result < cq_num) {
            int poll_once = ibv_poll_cq(qp->send_cq, cq_num - poll_result, &wc[poll_result]);
            if(poll_once != 0) {
                if(wc[poll_result].status != IBV_WC_SUCCESS) {
                    fprintf (stderr,
                             "got bad completion with status: 0x%x, vendor syndrome: 0x%x, with error %s\n",
                             wc[poll_result].status, wc[poll_result].vendor_err,ibv_wc_status_str(wc[poll_result].status));
                    // exit(-1);
                }
            }
            poll_result += poll_once;
        }
        qp->pendings = 0;
        return rc;
    }

}
