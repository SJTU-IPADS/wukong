#ifndef RDMA_UD_MSG_
#define RDMA_UD_MSG_

#include "rdmaio.h"
#include "rdma_msg.h"


namespace rdmaio {

  namespace udmsg {

    const int MAX_RECV_SIZE = 16;

    class UDMsg : public RDMA_msg {

    public:

      UDMsg();

      Qp::IOStatus send_to(int node_id,char *msg,int len);
      Qp::IOStatus broadcast_to(int *node_ids, int num_of_node, char *msg,int len);

      // force a sync among all current in-flight messages, return when all these msgs are ready
      void force_sync(int *node_id,int num_of_node);

      // Return true if one message is received
      bool  try_recv_from(int from_mac,char *buffer);

      // if we receive one
      void  ack_msg();

      int   get_num_nodes() { return num_nodes_; }
      int   get_thread_id() { return thread_id_; }

      virtual void check();

    private:
      Qp *ud_qp_;
      int num_nodes_;
      int thread_id_;

      // related to qp infos
      int recv_head_;
      int recv_step_;
      int idle_recv_num_;
      int max_idle_recv_num = 1;
      int max_recv_num;
      struct ibv_recv_wr rr_[MAX_RECV_SIZE];
      struct ibv_sge sge_[MAX_RECV_SIZE];
      struct ibv_wc wc_[MAX_RECV_SIZE];
    };
  };

};


#endif
